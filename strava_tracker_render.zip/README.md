# Strava GPS Tracker
A simple Flask app to count how many times Strava users pass near a specific GPS point.